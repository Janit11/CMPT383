import qualified Data.Map.Strict as Map
import qualified Data.Set as Set
import System.Environment (getArgs)
import Control.Monad.State.Lazy

type VarId = String

data Expr = CInt Int
          | CBool Bool
          | Var VarId
          | Plus Expr Expr
          | Minus Expr Expr
          | Equal Expr Expr
          | ITE Expr Expr Expr
          | Abs VarId Expr
          | App Expr Expr
          | LetIn VarId Expr Expr
          deriving (Eq, Ord, Read, Show)


data Type = TInt
          | TBool
          | TError
          | TVar Int
          | TArr Type Type
          deriving (Eq, Ord, Read, Show)

data Constraint = CEq Type Type
                | CError
                deriving (Eq, Ord, Read, Show)

type ConstraintSet = Set.Set Constraint
type ConstraintList = [Constraint]

type Env = Map.Map VarId Type

type InferState a = State Int a

getFreshTVar :: InferState Type
getFreshTVar = do 
                x <- get
                put (x + 1)
                return (TVar x)

infer :: Env -> Expr -> InferState (Type, ConstraintSet)
infer g (CInt _)  = return (TInt, Set.empty)
infer g (CBool _) = return (TBool, Set.empty)
infer g (Var x) = case Map.lookup x g of 
                    Just t -> return (t, Set.empty)
                    Nothing -> return (TError, Set.insert CError Set.empty)
infer g (Plus e1 e2) = do 
                        (t1, c1) <- infer g e1
                        (t2, c2) <- infer g e2
                        return (TInt, Set.unions [c1, c2, Set.fromList [CEq t1 TInt, CEq t2 TInt]])
infer g (Minus e1 e2) = do 
                        (t1, c1) <- infer g e1
                        (t2, c2) <- infer g e2
                        return (TInt, Set.unions [c1, c2, Set.fromList [CEq t1 TInt, CEq t2 TInt]])

infer g (Equal e1 e2) = do 
                        (t1, c1) <- infer g e1
                        (t2, c2) <- infer g e2
                        return (TBool, Set.unions [c1, c2, Set.singleton (CEq t1 t2)])

infer g (ITE e1 e2 e3) = do
                            (t1, c1) <- infer g e1
                            (t2, c2) <- infer g e2
                            (t3, c3) <- infer g e3
                            return (t2, Set.unions [c1, c2, c3, Set.fromList [CEq t1 TBool, CEq t2 t3]])

infer g (Abs x e) = do 
                        y <- getFreshTVar
                        (t, c) <- infer (Map.insert x y g) e
                        return (TArr y t, c)

infer g (App e1 e2) = do 
                        x1 <- getFreshTVar
                        x2 <- getFreshTVar
                        (t1, c1) <- infer g e1
                        (t2, c2) <- infer g e2
                        return (x2, Set.unions [c1, c2, Set.fromList [CEq t1 (TArr x1 x2), CEq t2 x1]]) 

infer g (LetIn v e1 e2) = do
                            x <- getFreshTVar
                            (t1, c1) <- infer (Map.insert v x g) e1
                            (t2, c2) <- infer (Map.insert v x g) e2
                            return (t2, Set.unions [c1, c2, Set.singleton (CEq x t1)])

inferExpr :: Expr -> (Type, ConstraintSet)
inferExpr e = evalState (infer Map.empty e) 0

toCstrList :: ConstraintSet -> ConstraintList
toCstrList = Set.toList

type Substitution = Map.Map Type Type

applySub :: Substitution -> Type -> Type
applySub s TInt = TInt
applySub s TBool = TBool
applySub s (TVar x) = case Map.lookup (TVar x) s of
                            Just t -> t
                            _ -> TVar x

applySub s (TArr t1 t2) = TArr (applySub s t1) (applySub s t2)
applySub s _ = TError

applySubToCstr :: Substitution -> Constraint -> Constraint
applySubToCstr s (CEq t1 t2) = CEq (applySub s t1) (applySub s t2)
applySubToCstr s CError = CError

applySubToCstrList :: Substitution -> ConstraintList -> ConstraintList
applySubToCstrList s = map (applySubToCstr s) 

composeSub :: Substitution -> Substitution -> Substitution
composeSub s1 s2 = Map.union (Map.map (applySub s1) s2)
                                (Map.withoutKeys s1 (Map.keysSet s2))

tvars :: Type -> Set.Set Type
tvars (TVar x) = Set.singleton (TVar x)
tvars (TArr i j) = Set.union (tvars i) (tvars j)
tvars _ = Set.empty

unify :: ConstraintList -> Maybe Substitution
unify [] = Just Map.empty
unify ((CEq t1 t2) : xs)
    | t1 == t2 = unify xs
    | ifVar t2 && Set.notMember t2 (tvars t1) = do 
                                                let s = Map.singleton t2 t1
                                                c <- unify (applySubToCstrList s xs)
                                                return (composeSub c s)
    | ifVar t1 && Set.notMember t1 (tvars t2) = do 
                                                let s = Map.singleton t1 t2
                                                c <- unify (applySubToCstrList s xs)
                                                return (composeSub c s)
    | otherwise = case (t1, t2) of 
                    (TArr i j, TArr k l) -> unify (Set.toList (Set.fromList (CEq i k : CEq j l : xs)))
                    _ -> Nothing
unify _ = Nothing

ifVar :: Type -> Bool
ifVar (TVar _) = True
ifVar _ = False

typing :: Expr -> Maybe Type
typing e = do 
                let (t, c) = inferExpr e
                s <- unify (toCstrList c)
                return (relabel (applySub s t))

type RelabelState a = State (Map.Map Int Int) a

relabel :: Type -> Type
relabel t = evalState (go t) Map.empty
    where
        go :: Type -> RelabelState Type
        go TInt = return TInt
        go TBool = return TBool
        go TError = return TError
        go (TVar x) = do m <- get
                         case Map.lookup x m of
                            Just v -> return (TVar v)
                            Nothing -> do let n = 1 + Map.size m
                                          put (Map.insert x n m)
                                          return (TVar n)
        go (TArr t1 t2) = do t1' <- go t1
                             t2' <- go t2
                             return (TArr t1' t2')

typeInfer :: Expr -> String
typeInfer e = maybe "Type Error" show (typing e)

readExpr :: String -> Expr
readExpr = read

main :: IO ()
main = do 
        args <- getArgs
        let filename = head args
        content <- readFile filename
        let ls = lines content
        mapM_ (putStrLn . typeInfer . readExpr) ls