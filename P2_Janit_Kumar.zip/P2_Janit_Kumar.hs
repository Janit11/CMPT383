import System.Directory.Internal.Prelude
import Data.Char
import System.IO
import System.Environment as Env
import Control.Applicative hiding (Const)

data Prop = Const Bool
            | Var String
            | Not Prop
            | And Prop Prop
            | Or Prop Prop
            | Imply Prop Prop
            | Iff Prop Prop
            deriving (Eq, Read, Show)

newtype Parser a = P (String -> [(a, String)])

parse :: Parser a -> String -> [(a, String)]
parse (P p) input = p input

item :: Parser Char 
item = P (\input -> case input of
                    []     -> []
                    (x:xs) -> [(x, xs)])

instance Functor Parser where
    fmap f p = P (\input -> case parse p input of
                            []         -> []
                            [(v, out)] -> [(f v, out)])

instance Applicative Parser where
    pure v = P (\input -> [(v, input)])
    pf <*> px = P (\input -> case parse pf input of 
                            []         -> []
                            [(f, out)] -> parse (fmap f px) out)

instance Monad Parser where
    p >>= f = P (\input -> case parse p input of
                        []         -> []
                        [(v, out)] -> parse (f v) out)

instance Alternative Parser where
    empty = P (\input -> [])
    p <|> q = P (\input -> case parse p input of
                            []        -> parse q input
                            [(v, out)] -> [(v, out)])


sat :: (Char -> Bool) -> Parser Char
sat p = do 
            x <- item
            if p x then return x else empty

digit :: Parser Char 
digit = sat isDigit

lower :: Parser Char
lower = sat isLower

alphanum :: Parser Char
alphanum = sat isAlphaNum

char :: Char -> Parser Char
char x = sat (== x)

string :: String -> Parser String 
string []    = return []
string (x:xs)= do 
                    char x 
                    string xs
                    return (x:xs)

ident :: Parser String
ident = do 
            x <- lower
            xs <- many alphanum
            return (x:xs)

nat :: Parser Int 
nat = do 
        xs <- some digit
        return (read xs)

space :: Parser ()
space = do 
            many (sat isSpace)
            return ()

token :: Parser a -> Parser a 
token p = do 
            space
            v <- p 
            space 
            return v 

identifier :: Parser String
identifier = token ident

natural :: Parser Int 
natural = token nat 

symbol :: String -> Parser String
symbol xs = token (string xs)

constT :: Parser Prop
constT = do symbol "T" 
            return (Const True)

constF :: Parser Prop
constF = do symbol "F" 
            return (Const False)

constant :: Parser Prop
constant = constT <|> constF

var :: Parser Prop
var = fmap Var identifier


formula :: Parser Prop 
formula = do 
            i <- impTerm 
            symbol "<->"
            f <- formula
            return (Iff i f)
            <|> impTerm

impTerm :: Parser Prop
impTerm = do 
            o <- orTerm
            symbol "->"
            i <- impTerm
            return (Imply o i)
            <|> orTerm

orTerm :: Parser Prop
orTerm = do 
            a <- andTerm
            symbol "\\/"
            o <- orTerm
            return (Or a o)
            <|> andTerm
            
andTerm :: Parser Prop
andTerm = do 
            n <- notTerm
            symbol "/\\"
            a <- andTerm
            return (And n a)
            <|> notTerm

notTerm :: Parser Prop
notTerm = do 
            symbol "!"
            n <- notTerm
            return (Not n)
            <|> factor

factor :: Parser Prop
factor = do 
            symbol "("
            f <- formula 
            symbol ")"
            return f 
            <|> constant
            <|> var


parseFormula :: String -> String
parseFormula input = case parse formula input of
                        [(v, "")] -> show v
                        [(v, _)] -> "Parse Error"
                        []       -> "Parse Error"


main :: IO ()
main = do
    args <- Env.getArgs
    let filename = head args
    content <- readFile filename
    let propFormulas = lines content
    mapM_ (putStrLn . parseFormula) propFormulas