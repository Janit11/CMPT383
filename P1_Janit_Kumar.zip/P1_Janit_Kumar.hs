import qualified System.Environment as Env
import qualified Data.Map.Strict as Map
import Data.List (nub)

data Prop = Const Bool
            | Var VarId
            | Not Prop
            | And Prop Prop
            | Or Prop Prop
            | Imply Prop Prop
            | Iff Prop Prop
            deriving (Eq, Read, Show)

type VarId  = String
type VarAsgn = Map.Map VarId Bool

findVarIds :: Prop -> [VarId]
findVarIds (Const _)     = []
findVarIds (Var v)       = [v]
findVarIds (Not a)       = findVarIds a
findVarIds (And a1 a2)   = nub (findVarIds a1 ++ findVarIds a2)
findVarIds (Or a1 a2)    = nub (findVarIds a1 ++ findVarIds a2)
findVarIds (Imply a1 a2) = nub (findVarIds a1 ++ findVarIds a2)
findVarIds (Iff a1 a2)   = nub (findVarIds a1 ++ findVarIds a2)

genVarAsgns :: [VarId] -> [VarAsgn]
genVarAsgns [] = [Map.empty]
genVarAsgns (a:as) = 
    let tempAsgns = genVarAsgns as
    in concat ( map (\x -> [Map.insert a True x, Map.insert a False x]) tempAsgns)


eval :: Prop -> VarAsgn -> Bool
eval (Const False) _ = False
eval (Const True)  _ = True
eval (Var v) x       = case Map.lookup v x of
                         Just val  -> val
                         Nothing -> error ( show v ++ " is not found")

eval (Not   a) b     = not (eval a b)
eval (And   a1 a2) b = eval a1 b && eval a2 b
eval (Or    a1 a2) b = eval a1 b || eval a2 b
eval (Imply a1 a2) b = not (eval a1 b) || (eval a2 b)
eval (Iff   a1 a2) b = eval a1 b == eval a2 b


sat :: Prop -> Bool
sat a = or . map (eval a) . genVarAsgns . findVarIds $ a


readFormula :: String -> Prop
readFormula fStr = read fStr

checkFormula :: String -> String
checkFormula fStr = case sat (readFormula fStr) of
    True  -> "SAT"
    False -> "UNSAT"


main :: IO ()
main = do
    args <- Env.getArgs
    let filename = head args
    content <- readFile filename
    let propFormulas = lines content
    mapM_ (putStrLn . checkFormula) propFormulas