import System.Environment (getArgs)
import qualified Data.Map.Strict as Map

data Type = TInt
          | TBool
          | TArr Type Type
          deriving (Eq, Ord, Read, Show)

type VarId = String

data Expr = CInt Int
          | CBool Bool
          | Var VarId
          | Plus Expr Expr
          | Minus Expr Expr
          | Equal Expr Expr
          | ITE Expr Expr Expr
          | Abs VarId Type Expr
          | App Expr Expr
          | LetIn VarId Type Expr Expr
          deriving (Eq, Ord, Read, Show)

type Env = Map.Map VarId Type

typingArith :: Maybe Type -> Maybe Type -> Maybe Type 
typingArith x1 x2 = case (x1,x2) of
                    (Just TInt, Just TInt) -> Just TInt
                    _                      -> Nothing


typingEq :: Maybe Type -> Maybe Type -> Maybe Type 
typingEq x1 x2 = case (x1,x2) of
                    (Just TInt, Just TInt) -> Just TBool
                    (Just TBool, Just TBool) -> Just TBool
                    _                        -> Nothing

typing :: Env -> Expr -> Maybe Type
typing k (CInt _) = Just TInt
typing k (CBool _) = Just TBool
typing k (Var x) = Map.lookup x k
typing k (Plus x1 x2) = typingArith (typing k x1) (typing k x2)
typing k (Minus x1 x2) = typingArith (typing k x1) (typing k x2)
typing k (Equal x1 x2) = typingEq (typing k x1) (typing k x2)
typing k (ITE x1 x2 x3) = case typing k x1 of
                            Just TBool -> let n1 = typing k x2
                                              n2 = typing k x3
                                          in if n1 == n2 
                                             then n1 else Nothing
                            _          -> Nothing

typing k (Abs x t e) = case typing (Map.insert x t k) e of 
                        Just n -> Just (TArr t n)
                        _      -> Nothing

typing k (App x1 x2) = case typing k x1 of
                        Just (TArr t1 t2) -> case typing k x2 of
                                                Just t3 -> if t1 == t3
                                                            then Just t2 else Nothing
                                                _       -> Nothing 
                        _                 -> Nothing

typing k (LetIn x t e1 e2) = case typing (Map.insert x t k) e1 of
                                Just n -> if t == n
                                          then typing (Map.insert x t k) e2 else Nothing
                                _ -> Nothing

readExpr :: String -> Expr
readExpr = read

typeCheck :: Expr -> String 
typeCheck x = maybe "Type Error" show (typing Map.empty x) 

main :: IO ()
main = do args <- getArgs
          let filename = head args
          content <- readFile filename
          let ls = lines content
          mapM_ (putStrLn . typeCheck . readExpr) ls